This is a fork of AutoDock Vina modified to output features for DeltaVinaRF20 score.

Changes from the AutoDock Vina version 1.1.2 are as follows:
* allow the output of 58 features 


Pre-build binary for linux is built on Centos 6.3 with boost 1.44.0 library.

Pre-build binary for Mac is built on MacOSX 10.10 with boost 1.41.0 library.

Examples can be found under test.


