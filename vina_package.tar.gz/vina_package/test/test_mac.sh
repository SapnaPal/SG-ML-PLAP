#! /bin/bash

../build/mac/release/vina --receptor 1a42/1a42_prot_nh_prep.pdbqt --ligand 1a42/1a42_lig_nh.pdbqt --score_only --log score.txt
